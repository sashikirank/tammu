<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'fu', 'zhuo', 'mao', 'fan', 'jia', 'mao', 'mao', 'ba', 'ci', 'mo', 'zi', 'di', 'chi', 'ji', 'jing', 'long',
  0x10 => 'cong', 'niao', 'yuan', 'xue', 'ying', 'qiong', 'ge', 'ming', 'li', 'rong', 'yin', 'gen', 'qian', 'chai', 'chen', 'yu',
  0x20 => 'hao', 'zi', 'lie', 'wu', 'ji', 'gui', 'ci', 'jian', 'ci', 'gou', 'guang', 'mang', 'cha', 'jiao', 'jiao', 'fu',
  0x30 => 'yu', 'zhu', 'zi', 'jiang', 'hui', 'yin', 'cha', 'fa', 'rong', 'ru', 'chong', 'mang', 'tong', 'zhong', 'qian', 'zhu',
  0x40 => 'xun', 'huan', 'fu', 'quan', 'gai', 'da', 'jing', 'xing', 'chuan', 'cao', 'jing', 'er', 'an', 'qiao', 'chi', 'ren',
  0x50 => 'jian', 'ti', 'huang', 'ping', 'li', 'jin', 'lao', 'shu', 'zhuang', 'da', 'jia', 'rao', 'bi', 'ze', 'qiao', 'hui',
  0x60 => 'ji', 'dang', 'yu', 'rong', 'hun', 'xing', 'luo', 'ying', 'xun', 'jin', 'sun', 'yin', 'mai', 'hong', 'zhou', 'yao',
  0x70 => 'du', 'wei', 'li', 'dou', 'fu', 'ren', 'yin', 'he', 'bi', 'bu', 'yun', 'di', 'tu', 'sui', 'sui', 'cheng',
  0x80 => 'chen', 'wu', 'bie', 'xi', 'geng', 'li', 'pu', 'zhu', 'mo', 'li', 'zhuang', 'zuo', 'tuo', 'qiu', 'sha', 'suo',
  0x90 => 'chen', 'peng', 'ju', 'mei', 'meng', 'xing', 'jing', 'che', 'shen', 'jun', 'yan', 'ting', 'you', 'cuo', 'guan', 'han',
  0xA0 => 'you', 'cuo', 'jia', 'wang', 'su', 'niu', 'shao', 'xian', 'lang', 'fu', 'e', 'mo', 'wen', 'jie', 'nan', 'mu',
  0xB0 => 'kan', 'lai', 'lian', 'shi', 'wo', 'tu', 'xian', 'huo', 'you', 'ying', 'ying', 'gong', 'chun', 'mang', 'mang', 'ci',
  0xC0 => 'wan', 'jing', 'di', 'qu', 'dong', 'jian', 'zou', 'gu', 'la', 'lu', 'ju', 'wei', 'jun', 'nie', 'kun', 'he',
  0xD0 => 'pu', 'zai', 'gao', 'guo', 'fu', 'lun', 'chang', 'chou', 'song', 'chui', 'zhan', 'men', 'cai', 'ba', 'li', 'tu',
  0xE0 => 'bo', 'han', 'bao', 'qin', 'juan', 'xi', 'qin', 'di', 'jie', 'pu', 'dang', 'jin', 'qiao', 'tai', 'geng', 'hua',
  0xF0 => 'gu', 'ling', 'fei', 'qin', 'an', 'wang', 'beng', 'zhou', 'yan', 'ju', 'jian', 'lin', 'tan', 'shu', 'tian', 'dao',
];

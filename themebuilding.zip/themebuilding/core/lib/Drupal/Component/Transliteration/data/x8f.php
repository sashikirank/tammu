<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'er', 'gong', 'ju', 'jiao', 'guang', 'he', 'kai', 'quan', 'zhou', 'zai', 'zhi', 'she', 'liang', 'yu', 'shao', 'you',
  0x10 => 'wan', 'yin', 'zhe', 'wan', 'fu', 'qing', 'zhou', 'ni', 'leng', 'zhe', 'zhan', 'liang', 'zi', 'hui', 'wang', 'chuo',
  0x20 => 'guo', 'kan', 'yi', 'peng', 'qian', 'gun', 'nian', 'ping', 'guan', 'bei', 'lun', 'pai', 'liang', 'ruan', 'rou', 'ji',
  0x30 => 'yang', 'xian', 'chuan', 'cou', 'chun', 'ge', 'you', 'hong', 'shu', 'fu', 'zi', 'fu', 'wen', 'ben', 'zhan', 'yu',
  0x40 => 'wen', 'tao', 'gu', 'zhen', 'xia', 'yuan', 'lu', 'jiao', 'chao', 'zhuan', 'wei', 'hun', 'xue', 'zhe', 'jiao', 'zhan',
  0x50 => 'bu', 'lao', 'fen', 'fan', 'lin', 'ge', 'se', 'kan', 'huan', 'yi', 'ji', 'zhui', 'er', 'yu', 'jian', 'hong',
  0x60 => 'lei', 'pei', 'li', 'li', 'lu', 'lin', 'che', 'ya', 'gui', 'xuan', 'dai', 'ren', 'zhuan', 'e', 'lun', 'ruan',
  0x70 => 'hong', 'gu', 'ke', 'lu', 'zhou', 'zhi', 'yi', 'hu', 'zhen', 'li', 'yao', 'qing', 'shi', 'zai', 'zhi', 'jiao',
  0x80 => 'zhou', 'quan', 'lu', 'jiao', 'zhe', 'fu', 'liang', 'nian', 'bei', 'hui', 'gun', 'wang', 'liang', 'chuo', 'zi', 'cou',
  0x90 => 'fu', 'ji', 'wen', 'shu', 'pei', 'yuan', 'xia', 'nian', 'lu', 'zhe', 'lin', 'xin', 'gu', 'ci', 'ci', 'pi',
  0xA0 => 'zui', 'bian', 'la', 'la', 'ci', 'xue', 'ban', 'bian', 'bian', 'bian', 'xue', 'bian', 'ban', 'ci', 'bian', 'bian',
  0xB0 => 'chen', 'ru', 'nong', 'nong', 'chan', 'chuo', 'chuo', 'yi', 'reng', 'bian', 'bian', 'shi', 'ru', 'liao', 'da', 'chan',
  0xC0 => 'gan', 'qian', 'yu', 'yu', 'qi', 'xun', 'yi', 'guo', 'mai', 'qi', 'za', 'wang', 'tu', 'zhun', 'ying', 'ti',
  0xD0 => 'yun', 'jin', 'hang', 'ya', 'fan', 'wu', 'da', 'e', 'hai', 'zhe', 'zhong', 'jin', 'yuan', 'wei', 'lian', 'chi',
  0xE0 => 'che', 'ni', 'tiao', 'zhi', 'yi', 'jiong', 'jia', 'chen', 'dai', 'er', 'di', 'po', 'zhu', 'die', 'ze', 'tao',
  0xF0 => 'shu', 'tuo', 'qu', 'jing', 'hui', 'dong', 'you', 'mi', 'beng', 'ji', 'nai', 'yi', 'jie', 'zhui', 'lie', 'xun',
];
